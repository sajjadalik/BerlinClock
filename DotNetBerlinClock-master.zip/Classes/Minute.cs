﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BerlinClock.Classes
{
    public class Minute : ITimeUnit
    {
        private static readonly char RED_LIGHT = 'R';
        private static readonly char YELLOW_LIGHT = 'Y';
        private static readonly string ALL_FOUR_LIGHTS_OFF = "OOOO";
        private static readonly string ALL_ELEVEN_LIGHTS_OFF = "OOOOOOOOOOO";

        public string GetLamps(int unit)
        {
            int minutesDividedBy5 = unit / 5;
            int minutesModulus5 = unit % 5;

            return GetLampsForMinutesMultiplesOfFive(minutesDividedBy5) + "\n" + GetLampsForSingleMinutes(minutesModulus5);
        }

        private string GetLampsForMinutesMultiplesOfFive(int minutes)
        {
            StringBuilder lamps = new StringBuilder(ALL_ELEVEN_LIGHTS_OFF);

            for (int i = 0; i < minutes; i++)
                if (0 == (i + 1) % 3)
                    lamps[i] = RED_LIGHT;
                else
                    lamps[i] = YELLOW_LIGHT;

            return lamps.ToString();
        }

        private string GetLampsForSingleMinutes(int minutes)
        {
            StringBuilder lamps = new StringBuilder(ALL_FOUR_LIGHTS_OFF);

            for (int i = 0; i < minutes; i++)
                lamps[i] = YELLOW_LIGHT;

            return lamps.ToString();
        }
    }
}
