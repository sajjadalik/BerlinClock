﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BerlinClock.Classes
{
    public class Hour : ITimeUnit
    {
        private static readonly string ALL_LIGHTS_OFF = "OOOO";
        private static readonly char RED_LIGHT = 'R';
        private static readonly int MULTIPLE_OF_FIVE = 5;

        public string GetLamps(int unit) => GetLampsForHoursMultiplesOfFive(unit) + "\n" + GetLampsForSingleHours(unit);

        public string GetLampsForHoursMultiplesOfFive(int hours)
        {
            StringBuilder lamps = new StringBuilder(ALL_LIGHTS_OFF);

            for (int i = 0; i < (hours / MULTIPLE_OF_FIVE); i++)
                lamps[i] = RED_LIGHT;

            return lamps.ToString();
        }

        public string GetLampsForSingleHours(int hours)
        {
            StringBuilder lamps = new StringBuilder(ALL_LIGHTS_OFF);

            for (int i = 0; i < (hours % MULTIPLE_OF_FIVE); i++)
                lamps[i] = RED_LIGHT;

            return lamps.ToString();
        }
    }
}
