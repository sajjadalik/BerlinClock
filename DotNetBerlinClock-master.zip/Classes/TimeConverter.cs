﻿using BerlinClock.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BerlinClock
{
    public class TimeConverter : ITimeConverter
    {
        private static List<ITimeUnit> timeUnits = new List<ITimeUnit>();

        public string ConvertTime(string time)
        {
            timeUnits = new List<ITimeUnit>();
            timeUnits.Add(new Second());
            timeUnits.Add(new Hour());
            timeUnits.Add(new Minute());

            StringBuilder timeSB = new StringBuilder();
            string[] timeElements = time.Split(':');

            int i = 0;
            int j = 2;

            foreach (var timeUnit in timeUnits)
            {
                foreach (string timeElement in timeElements)
                {
                    timeSB.Append(timeUnits[i].GetLamps(int.Parse(timeElements[j]))).Append("\n");
                    i++;
                    j = j == 0 ? 1 : 0;
                    break;
                }
            }

            return timeSB.ToString().Substring(0, timeSB.ToString().Length - 1);
        }
    }
}
