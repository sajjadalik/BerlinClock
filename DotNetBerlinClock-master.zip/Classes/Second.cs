﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BerlinClock.Classes
{
    public class Second : ITimeUnit
    {
        public string GetLamps(int unit) => 0 == unit % 2 ? "Y" : "O";
    }
}
